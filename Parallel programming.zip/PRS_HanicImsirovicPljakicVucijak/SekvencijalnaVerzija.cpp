#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include <iostream>
#include <string.h>
#include <chrono>
#include <omp.h>
#include <fstream>

#define MAX_STR_LEN 70000

long long int prime(long long int);
long long int gcd(long long int p, long long int q);
int publickey(long long int p, long long int q, long long int* exp, long long int* mod);
int privatekey(long long int p, long long int q, long long int pubexp, long long int* exp, long long int* mod);
int EncryptDecrypt(long long int* in, long long int exp, long long int mod, long long int* out, size_t len);
int char2long(char* in, long long int* out);
int long2char(long long int* in, char* out);

int main(void)
{
    long long int p, q, pube, pubmod, prive, privmod;
    char inmsg[MAX_STR_LEN];
    long long int inmsg_l[MAX_STR_LEN];
    char outmsg[MAX_STR_LEN];
    long long int outmsg_l[MAX_STR_LEN];
    long long int resulting_1;
    char resulting[MAX_STR_LEN];
    char decrmsg[MAX_STR_LEN];
    long long int decrmsg_l[MAX_STR_LEN];

    size_t len;

    std::cout << "ENTER A PRIME NUMBER" << std::endl;
    std::cin >> p;
    if (prime(p))
    {
        std::cerr << p << " is not prime." << std::endl;
        return 1;
    }
    std::cout << "ENTER ANOTHER PRIME NUMBER" << std::endl;
    std::cin >> q;
    if (prime(q))
    {
        std::cerr << q << " is not prime." << std::endl;
        return 1;
    }

    std::string inFileName = "message.txt";
    std::ifstream inFile;
    int br2 = 0;
    char ch;
    inFile.open(inFileName.c_str());

     if (inFile.is_open())
     {
        while (inFile >> std::noskipws >> ch) {
            inmsg[br2] = ch;
            br2++;
        }
        inFile.close();
     }

    len = strlen(inmsg);

    // Start clock
    auto begin = std::chrono::high_resolution_clock::now();

    // Generate public and private keys from p and q
    publickey(p, q, &pube, &pubmod);
    privatekey(p, q, pube, &prive, &privmod);

    // Convert to long long ints
    char2long(inmsg, inmsg_l);

    //Encrypt
    EncryptDecrypt(inmsg_l, pube, pubmod, outmsg_l, len);

    //Decrypt
    EncryptDecrypt(outmsg_l, prive, privmod, decrmsg_l, len);
    long2char(decrmsg_l, decrmsg);

    // Stop clock
    auto end = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin);

    // ---- Outputs

    // Output of keys
    std::cout << "public key: " << pube << ", " << pubmod << std::endl;
    std::cout << std::endl;
    std::cout << "private key: " << prive << ", " << privmod << std::endl;
    std::cout << std::endl;

    // Output of original text
    std::cout << "Original text: " << inmsg << std::endl;
    std::cout << std::endl;

    // Output of encrypted text
    std::string str;
    int br = 0;
    for (int x : outmsg_l)
    {
        if (br >= len)
            break;
        str += std::to_string(x);
        br++;
    }

    std::cout << "Encrypted text: " << str << std::endl;
    std::cout << std::endl;

    // Output of decrypted text
    std::cout << "Decrypted text: " << decrmsg << std::endl;
    std::cout << std::endl;

    // Output of measured time
    std::cout << "Time measured: " << elapsed.count() * 1e-9 << "seconds.\n";
}


long long int prime(long long int p)
{
   long long int j = sqrt(p);
   for (long long int z=2;z<j;z++) if (0==p%z) return z;
   return 0;
}

int publickey(long long int p, long long int q, long long int *exp, long long int *mod)
{

   *mod = (p-1)*(q-1);
   *exp = (int)sqrt(*mod);
   while (1!=gcd(*exp,*mod))
   {
      (*exp)++;
   }
   *mod = p*q;
   return 0;
}

int privatekey(long long int p, long long int q, long long int pubexp, long long int *exp, long long int *mod)

{
   *mod = (p-1)*(q-1);
   *exp = 1;
   long long int tmp=pubexp;
   while(1!=tmp%*mod)
   {
      tmp+=pubexp;
      tmp%=*mod;
      (*exp)++;
   }
   *mod = p*q;
   return 0;
}

int EncryptDecrypt(long long int* in, long long int exp, long long int mod, long long int* out, size_t len) {
    for (long long int *pc = in; *pc != '\0';pc++,out++)
    {
      long long int c = *pc;
      for (int z=1;z<exp;z++)
      {
         c *= *pc;
         c %= mod;

      }
      *out = c;
    }
   *out='\0';
    return 0;
}

long long int gcd(long long int p, long long int q)
{
   if (p<q) {long long int tmp=p;p=q;q=tmp;}
   while (q!=0)
   {
      long long int tmp = q;
      q = p%q;
      p = tmp;
   }
   return p;
}

int long2char(long long int* in, char* out)
{
   while(*in != 0) {
        *out++ = (char)(*in++);
   }
   *out = '\0';
   return 0;
}

int char2long(char* in, long long int* out)
{
   while(*in != '\0') *out++ = (long long int)(*in++);
   *out = 0;
   return 0;
}
