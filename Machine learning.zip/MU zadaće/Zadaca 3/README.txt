Radi pojavljivanja random znakova u R fajlovima, u prilogu postavljamo i txt fajl sa kodovima zadatka 1a i 1b
