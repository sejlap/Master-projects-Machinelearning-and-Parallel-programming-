library(tidyverse)  # data manipulation
library(cluster)    # clustering algorithms
library(factoextra) # clustering visualization
library(dendextend)

getwd()
setwd("C:/Users/User/Documents/Zadaca3")
obesity<-read.csv("ObesityDataSet.csv", header=T)
View(?besity)
# matrica razli�itosti
d <- dist(obesity, method = "euclidean")

# hijerarhijski klastering koristeci complete povezanost 
hc1 <- hclust(d, method = "complete" )
# Prikaz dendrograma
plot(hc1, cex = 0.6, hang = -1)

# Ra�unanje koriste�i agnes meto?u
hc2 <- agnes(obesity, method = "complete")

# Aglomerativni koeficijent
hc2$ac
## 0.9896456

# Procjena Wardove metode
m <- c( "average", "single", "complete", "ward")
names(m) <- c( "average", "single", "complete", "ward")

# function to compute coeffic?ent
ac <- function(x) {
  agnes(obesity, method = x)$ac
}
library(purrr)
map_dbl(m, ac)

#average    single  complete      ward 
#0.9709722 0.9273958 0.9896456 0.9990174 
hc3 <- agnes(obesity, method = "ward")
#Prikaz dendograma koriste�i agnes algoritam
p?tree(hc3, cex = 0.6, hang = -1, main = "Dendrogram of agnes")


# ra�unanje klasteringa pomocu diana algoritma - algoritam dijeljenja 
hc4 <- diana(obesity)
# Koeficijent dijeljenja - koli�ina strukture klasteringa
hc4$dc
## [1] 0.9883536
# plot dendrogram?pltree(hc4, cex = 0.6, hang = -1, main = "Dendrogram of diana")

#prikaz dendrograma

# Wardova metoda
hc5 <- hclust(d, method = "ward.D2" )
sub_grp <- cutree(hc5, k = 4)
# Broj elemenata u svakom klasteru
table(sub_grp)
obesity %>%
  mutate(cluster = sub_?rp) %>%
  head

plot(hc5, cex = 0.6)
rect.hclust(hc5, k = 4, border = 2:5)

#Cut agnes() u 4 grupe
hc_a <- agnes(obesity, method = "ward")
cutree(as.hclust(hc_a), k = 4)

# Cut diana() tree u 4 grupe
hc_d <- diana(obesity)
cutree(as.hclust(hc_d), k = 4)


? racunanje distance
res.dist <- dist(obesity, method = "euclidean")

# racunanje distance 2 klastera
hc1 <- hclust(res.dist, method = "complete")
hc2 <- hclust(res.dist, method = "ward.D2")

# kreiranje 2 dendrograma
dend1 <- as.dendrogram (hc1)
dend2 <- a?.dendrogram (hc2)

tanglegram(dend1, dend2)

#validacija najboljeg klastera
fviz_nbclust(obesity, FUN = hcut, method = "wss")
fviz_nbclust(obesity, FUN = hcut, method = "silhouette")




#PROCESIRANJE SETA PODATAKA

#distribucija
boxplot(obesity$Age)
skewn?ss(obesity$Age) #1.52
#log transformacija
obesity$Age<- log(obesity$Age - (min(obesity$Age)-1)) 
skewness(obesity$Age) #0.21

boxplot(obesity$Height)
skewness(obesity$Height) #-0.012
obesity$Height<-obesity$Height^(2) #smaknutost 0.105

boxplot(obesity$Wei?ht) #0.255 
skewness(obesity$Weight)

boxplot(obesity$FCVC)
skewness(obesity$FCVC) #-0.4322
#square transformation
obesity$FCVC<-obesity$FCVC^(2) # smaknutost -0.09

boxplot(obesity$NCP)
skewness(obesity$NCP) # -1.105
#square transformation 
obesity$NCP<-o?esity$NCP^(2) #smaknutost -0.408

boxplot(obesity$CH2O)
skewness(obesity$CH2O) #-0.104
#square transformation
obesity$CH2O<-obesity$CH2O  ^(2) #smaknutost #0.399

boxplot(obesity$FAF)
skewness(obesity$FAF) #0.4977

boxplot(obesity$TUE)
skewness(obesity$TUE? #0.617

#provjera nedostajucih vrijednosti
count_NA <- sapply(obesity, function(x) sum(length(which(is.na(x)))))
count_NA <- data.frame(count_NA)
count_NA
#neddostajucih vrijednosti nema
#provjera balansiranosti
prop.table(table(obesity$NObeyesdad)) #dobr? balansiranost
table(obesity$NObeyesdad)



# matrica razli�itosti
d <- dist(obesity, method = "euclidean")

# hijerarhijski klastering koristeci complete povezanost 
hc1 <- hclust(d, method = "complete" )
# Prikaz dendrograma
plot(hc1, cex = 0.6, hang = -?)

# Ra�unanje koriste�i agnes metodu
hc2 <- agnes(obesity, method = "complete")

# Aglomerativni koeficijent
hc2$ac
## 0.9896456

# Procjena Wardove metode
m <- c( "average", "single", "complete", "ward")
names(m) <- c( "average", "single", "complete", "w?rd")

# function to compute coefficient
ac <- function(x) {
  agnes(obesity, method = x)$ac
}
library(purrr)
map_dbl(m, ac)

#average    single  complete      ward 
#0.9709722 0.9273958 0.9896456 0.9990174 
hc3 <- agnes(obesity, method = "ward")
#Prikaz de?dograma koriste�i agnes algoritam
pltree(hc3, cex = 0.6, hang = -1, main = "Dendrogram of agnes")


# ra�unanje klasteringa pomocu diana algoritma - algoritam dijeljenja 
hc4 <- diana(obesity)
# Koeficijent dijeljenja - koli�ina strukture klasteringa
hc4$d?
#[1] 0.9861251
# plot dendrogram
pltree(hc4, cex = 0.6, hang = -1, main = "Dendrogram of diana")

#prikaz dendrograma

# Wardova metoda
hc5 <- hclust(d, method = "ward.D2" )
sub_grp <- cutree(hc5, k = 4)
# Broj elemenata u svakom klasteru
table(sub_grp)
o?esity %>%
  mutate(cluster = sub_grp) %>%
  head

plot(hc5, cex = 0.6)
rect.hclust(hc5, k = 4, border = 2:5)

#Cut agnes() u 4 grupe
hc_a <- agnes(obesity, method = "ward")
cutree(as.hclust(hc_a), k = 4)

# Cut diana() tree u 4 grupe
hc_d <- diana(obesity)?cutree(as.hclust(hc_d), k = 4)


# racunanje distance
res.dist <- dist(obesity, method = "euclidean")

# racunanje distance 2 klastera
hc1 <- hclust(res.dist, method = "complete")
hc2 <- hclust(res.dist, method = "ward.D2")

# kreiranje 2 dendrograma
dend1?<- as.dendrogram (hc1)
dend2 <- as.dendrogram (hc2)

tanglegram(dend1, dend2)

#validacija najboljeg klastera
fviz_nbclust(obesity, FUN = hcut, method = "wss")
fviz_nbclust(obesity, FUN = hcut, method = "silhouette")





#Hijerarhiijski algoritam nad proc?suiranim PCA
# matrica razli�itosti
d <- dist(PCAnovi, method = "euclidean")

# hijerarhijski klastering koristeci complete povezanost 
hc1 <- hclust(d, method = "complete" )
# Prikaz dendrograma
plot(hc1, cex = 0.6, hang = -1)

# Ra�unanje koriste�i agnes?metodu
hc2 <- agnes(PCAnovi, method = "complete")

# Aglomerativni koeficijent
hc2$ac
## [1] 0.9882099

# Procjena Wardove metode
m <- c( "average", "single", "complete", "ward")
names(m) <- c( "average", "single", "complete", "ward")

# function to comput? coefficient
ac <- function(x) {
  agnes(PCAnovi, method = x)$ac
}
library(purrr)
map_dbl(m, ac)

#average    single  complete      ward 
#0.9666940 0.8361703 0.9882099 0.9988943

hc3 <- agnes(PCAnovi, method = "ward")
#Prikaz dendograma koriste�i agnes al?oritam
pltree(hc3, cex = 0.6, hang = -1, main = "Dendrogram of agnes")


# ra�unanje klasteringa pomocu diana algoritma - algoritam dijeljenja 
hc4 <- diana(PCAnovi)
# Koeficijent dijeljenja - koli�ina strukture klasteringa
hc4$dc
## [1] 0.9868763
# plot d?ndrogram
pltree(hc4, cex = 0.6, hang = -1, main = "Dendrogram of diana")

#prikaz dendrograma

# Wardova metoda
hc5 <- hclust(d, method = "ward.D2" )
sub_grp <- cutree(hc5, k = 4)
# Broj elemenata u svakom klasteru
table(sub_grp)
PCAnovi %>%
  mutate(clust?r = sub_grp) %>%
  head

plot(hc5, cex = 0.6)
rect.hclust(hc5, k = 4, border = 2:5)

fviz_cluster(list(data = PCAnovi, cluster = sub_grp))
#Cut agnes() u 4 grupe
hc_a <- agnes(PCAnovi, method = "ward")
cutree(as.hclust(hc_a), k = 4)

# Cut diana() tree u 4?grupe
hc_d <- diana(PCAnovi)
cutree(as.hclust(hc_d), k = 4)


# racunanje distance
res.dist <- dist(PCAnovi, method = "euclidean")

# racunanje distance 2 klastera
hc1 <- hclust(res.dist, method = "complete")
hc2 <- hclust(res.dist, method = "ward.D2")

# ?reiranje 2 dendrograma
dend1 <- as.dendrogram (hc1)
dend2 <- as.dendrogram (hc2)

tanglegram(dend1, dend2)

#validacija najboljeg klastera
fviz_nbclust(PCAnovi, FUN = hcut, method = "wss")
fviz_nbclust(PCAnovi, FUN = hcut, method = "silhouette")




