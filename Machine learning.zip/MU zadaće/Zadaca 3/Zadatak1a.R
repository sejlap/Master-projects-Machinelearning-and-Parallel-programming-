library(e1071)
library(caret)
library(ISLR)
library(MASS)
library(RCurl)
library(dbscan)
library(cluster)
library(factoextra) 
library(BBmisc)
library(ClusterR) 
library(NbClust)
library(stats)
library(fpc)

getwd()
setwd("C:/Users/User/Documents/Zadaca3")?obesity<-read.csv("ObesityDataSet.csv", header=T)
View(obesity)
#tipovi atributa 
str(obesity)
summary(obesity)


#PCA NAD ORGINALNIM SKUPOM PODATAKA
orginal<-obesity
#PCA radi samo sa numeri�kim varijablama
PCAorginal <- orginal[,-c(1, 5, 6, 9, 10,12,15,1?,17)] 
View(PCAorginal)

#prosje�nu vrijednost svih varijabli u setu podataka
apply(PCAorginal, 2, mean)
#varijansa svih vrijednosti u setu podataka
apply(PCAorginal, 2, var)

#izvr�avanje PCA, sa skaliranjem varijabli
pr.out<-prcomp(PCAorginal, scale=TRUE?
summary(pr.out)
biplot(pr.out,scale=0)

#Plotting varijanse i kumulativne varianse
pr.var<-pr.out$sdev^2
pve<-pr.var/sum(pr.var)
plot(pve, xlab="Principal Component", ylab="Proportion of Variance Explained", ylim=c(0,1) ,type="b")
plot(cumsum(pve), xlab="?rincipal Component", ylab ="Cumulative Proportion of Variance Explained", ylim=c(0,1), type="b")

#PAM NAD ORGINALNIM SKUPOM PODATAKA

PAMorginal<-obesity

PAMorginal$Gender<-as.factor(PAMorginal$Gender)
PAMorginal$family_history_with_overweight<-as.factor?PAMorginal$family_history_with_overweight)
PAMorginal$FAVC<-as.factor(PAMorginal$FAVC)
PAMorginal$CAEC<-as.factor(PAMorginal$CAEC)
PAMorginal$SMOKE<-as.factor(PAMorginal$SMOKE)
PAMorginal$SCC<-as.factor(PAMorginal$SCC)
PAMorginal$CALC<-as.factor(PAMorginal?CALC)
PAMorginal$MTRANS<-as.factor(PAMorginal$MTRANS)
PAMorginal$NObeyesdad<-as.factor(PAMorginal$NObeyesdad)


gower_dist<-daisy(PAMorginal, metric="gower")
summary(gower_dist)
gower_mat <- as.matrix(gower_dist)
PAMorginal[which(gower_mat==min(gower_mat[g?wer_mat!=0]),arr.ind=TRUE)[1, ], ]
PAMorginal[which(gower_mat==max(gower_mat),arr.ind = TRUE)[1, ], ]

#best k
sil_width<-c(NA)
for(i in 2:10){
  pam_fit<-pam(gower_dist, diss = TRUE, k=i)
  sil_width[i] <- pam_fit$silinfo$avg.width
}

plot(1:10, sil_width? xlab = "Broj klastera", ylab = "Silouetthe")
lines(1:10, sil_width)

pam_fit<-pam(gower_dist, diss = TRUE, k=3)
results<-as.data.frame(pam_fit$clustering)
results
colnames(results)<-"Cluster"
results$People<-rownames(results)
PAMorginal$People<-rownames(P?Morginal)
PAMorginal<-merge(PAMorginal,results, by="People")
rownames(PAMorginal)<-PAMorginal$People

with(PAMorginal , aggregate(PAMorginal[,1:19] , by=list(Cluster) , FUN=summary))

PAMorginal[PAMorginal$People==pam_fit$medoids,]

#Iscrtavanje interesant?ih osobina dataseta
boxplot(PAMorginal$Weight~PAMorginal$Cluster)
boxplot(PAMorginal$Height~PAMorginal$Cluster)
boxplot(PAMorginal$TUE~PAMorginal$Cluster)

#klaster tendencija
novi<-obesity
data <- novi[,-c(1, 5, 6, 9, 10,12,15,16,17)]
View(data)
#hopkins ?tatistika za dataset (iznosi oko 0.9, sto znaci da je velika klastering tendencija 
hop <- get_clust_tendency(data,n = 50 ,graph = FALSE)
hop$hopkins_stat

#PROCESIRANJE SETA PODATAKA

#distribucija
boxplot(obesity$Age)
skewness(obesity$Age) #1.52
#log tra?sformacija
obesity$Age<- log(obesity$Age - (min(obesity$Age)-1)) 
skewness(obesity$Age) #0.21

boxplot(obesity$Height)
skewness(obesity$Height) #-0.012
obesity$Height<-obesity$Height^(2) #smaknutost 0.105

boxplot(obesity$Weight) #0.255 
skewness(obesity$W?ight)

boxplot(obesity$FCVC)
skewness(obesity$FCVC) #-0.4322
#square transformation
obesity$FCVC<-obesity$FCVC^(2) # smaknutost -0.09

boxplot(obesity$NCP)
skewness(obesity$NCP) # -1.105
#square transformation 
obesity$NCP<-obesity$NCP^(2) #smaknutost -0.4?8

boxplot(obesity$CH2O)
skewness(obesity$CH2O) #-0.104
#square transformation
obesity$CH2O<-obesity$CH2O  ^(2) #smaknutost #0.399

boxplot(obesity$FAF)
skewness(obesity$FAF) #0.4977

boxplot(obesity$TUE)
skewness(obesity$TUE) #0.617

#provjera nedostajuci? vrijednosti
count_NA <- sapply(obesity, function(x) sum(length(which(is.na(x)))))
count_NA <- data.frame(count_NA)
count_NA
#neddostajucih vrijednosti nema
#provjera balansiranosti
prop.table(table(obesity$NObeyesdad)) #dobra balansiranost
table(obesity$N?beyesdad)


#PCA NAD PROCESIRANIM SKUPOM

PCAnovi<-obesity

PCAnovi$Gender[PCAnovi$Gender == 'Female'] = "1"
PCAnovi$Gender[PCAnovi$Gender == 'Male'] = "0"

PCAnovi$family_history_with_overweight[PCAnovi$family_history_with_overweight  == 'yes'] = "1"
PCAn?vi$family_history_with_overweight[PCAnovi$family_history_with_overweight  == 'no'] = "0"

PCAnovi$FAVC[PCAnovi$FAVC  == 'yes'] = "1"
PCAnovi$FAVC[PCAnovi$FAVC  == 'no'] = "0"

PCAnovi$CAEC[PCAnovi$CAEC == 'no'] = "0"
PCAnovi$CAEC[PCAnovi$CAEC == 'Sometimes?] = "1"
PCAnovi$CAEC[PCAnovi$CAEC == 'Frequently'] = "2"
PCAnovi$CAEC[PCAnovi$CAEC == 'Always'] = "4"

PCAnovi$CALC[PCAnovi$CALC == 'no'] = "0"
PCAnovi$CALC[PCAnovi$CALC == 'Sometimes'] = "1"
PCAnovi$CALC[PCAnovi$CALC == 'Frequently'] = "2"
PCAnovi$CALC[PC?novi$CALC == 'Always'] = "4"

PCAnovi$SMOKE[PCAnovi$SMOKE  == 'yes'] = "1"
PCAnovi$SMOKE[PCAnovi$SMOKE  == 'no'] = "0"

PCAnovi$SCC[PCAnovi$SCC  == 'yes'] = "1"
PCAnovi$SCC[PCAnovi$SCC  == 'no'] = "0"

PCAnovi$MTRANS[PCAnovi$MTRANS  == 'Motorbike'] = "1"
P?Anovi$MTRANS[PCAnovi$MTRANS  == 'Automobile'] = "2"
PCAnovi$MTRANS[PCAnovi$MTRANS  == 'Bike'] = "3"
PCAnovi$MTRANS[PCAnovi$MTRANS  == 'Public_Transportation'] = "4"
PCAnovi$MTRANS[PCAnovi$MTRANS  == 'Walking'] = "5"


PCAnovi$NObeyesdad[PCAnovi$NObeyesdad ?== 'Insufficient_Weight'] = "0"
PCAnovi$NObeyesdad[PCAnovi$NObeyesdad  == 'Normal_Weight'] = "1"
PCAnovi$NObeyesdad[PCAnovi$NObeyesdad  == 'Overweight_Level_I'] = "2"
PCAnovi$NObeyesdad[PCAnovi$NObeyesdad  == 'Overweight_Level_II'] = "3"
PCAnovi$NObeyesdad?PCAnovi$NObeyesdad  == 'Obesity_Type_I'] = "4"
PCAnovi$NObeyesdad[PCAnovi$NObeyesdad  == 'Obesity_Type_II'] = "5"
PCAnovi$NObeyesdad[PCAnovi$NObeyesdad  == 'Obesity_Type_III'] = "6"

PCAnovi$Gender<-as.numeric(PCAnovi$Gender)
PCAnovi$family_history_with_ov?rweight<-as.numeric(PCAnovi$family_history_with_overweight)
PCAnovi$FAVC<-as.numeric(PCAnovi$FAVC)
PCAnovi$CAEC<-as.numeric(PCAnovi$CAEC)
PCAnovi$CALC<-as.numeric(PCAnovi$CALC)
PCAnovi$SCC<-as.numeric(PCAnovi$SCC)
PCAnovi$MTRANS<-as.numeric(PCAnovi$MTRANS)?PCAnovi$SMOKE<-as.numeric(PCAnovi$SMOKE)
PCAnovi$NObeyesdad<-as.numeric(PCAnovi$NObeyesdad)

#prosje�nu vrijednost svih varijabli u setu podataka
apply(PCAnovi, 2, mean)
#varijansa svih vrijednosti u setu podataka
apply(PCAnovi, 2, var)

pr.out<-prcomp(PCA?ovi, scale=TRUE)
summary(pr.out)
biplot(pr.out,scale=0)

##Plotting variance and cumulative variance
pr.var<-pr.out$sdev^2
pve<-pr.var/sum(pr.var)
plot(pve, xlab="Principal Component", ylab="Proportion of Variance Explained", ylim=c(0,1) ,type="b")
plot(cu?sum(pve), xlab="Principal Component", ylab ="Cumulative Proportion of Variance Explained", ylim=c(0,1), type="b")



#klaster tendencija
novi<-obesity
data <- novi[,-c(1, 5, 6, 9, 10,12,15,16,17)]
View(data)
#hopkins statistika za dataset (iznosi oko 0.78,?sto znaci da je velika klastering tendencija 
hop <- get_clust_tendency(data,n = 50 ,graph = FALSE)
hop$hopkins_stat


#PAM NAD PROCESIRANIM SKUPOM PODATAKA

obesity$Gender<-as.factor(obesity$Gender)
obesity$family_history_with_overweight<-as.factor(obesit?$family_history_with_overweight)
obesity$FAVC<-as.factor(obesity$FAVC)
obesity$CAEC<-as.factor(obesity$CAEC)
obesity$SMOKE<-as.factor(obesity$SMOKE)
obesity$SCC<-as.factor(obesity$SCC)
obesity$CALC<-as.factor(obesity$CALC)
obesity$MTRANS<-as.factor(obesity?MTRANS)
obesity$NObeyesdad<-as.factor(obesity$NObeyesdad)

gower_dist<-daisy(obesity, metric="gower")
summary(gower_dist)
gower_mat <- as.matrix(gower_dist)
obesity[which(gower_mat==min(gower_mat[gower_mat!=0]),arr.ind=TRUE)[1, ], ]
obesity[which(gower_mat?=max(gower_mat),arr.ind = TRUE)[1, ], ]

#best k
sil_width<-c(NA)
for(i in 2:10){
  pam_fit<-pam(gower_dist, diss = TRUE, k=i)
  sil_width[i] <- pam_fit$silinfo$avg.width
}

plot(1:10, sil_width, xlab = "Broj klastera", ylab = "Silouetthe")
lines(1:10, sil?width)

pam_fit<-pam(gower_dist, diss = TRUE, k=3)
results<-as.data.frame(pam_fit$clustering)
colnames(results)<-"Cluster"
results$People<-rownames(results)
obesity$People<-rownames(obesity)
obesity<-merge(obesity,results, by="People")
rownames(obesity)<-o?esity$People

with(obesity , aggregate(obesity[,1:19] , by=list(Cluster) , FUN=summary))

obesity[obesity$People==pam_fit$medoids,]


#PAM nad PCA koji nije prethodno procesuiran
set.seed(1)
gower_dist<-daisy(PCAorginal, metric="gower")
summary(gower_dist)?gower_mat <- as.matrix(gower_dist)
PCAorginal[which(gower_mat==min(gower_mat[gower_mat!=0]),arr.ind=TRUE)[1, ], ]
PCAorginal[which(gower_mat==max(gower_mat),arr.ind = TRUE)[1, ], ]

#best k
sil_width<-c(NA)
for(i in 2:10){
  pam_fit<-pam(gower_dist, diss =?TRUE, k=i)
  sil_width[i] <- pam_fit$silinfo$avg.width
}

plot(1:10, sil_width, xlab = "Broj klastera", ylab = "Silouetthe")
lines(1:10, sil_width)

pam_fit<-pam(gower_dist, diss = TRUE, k=3)
results<-as.data.frame(pam_fit$clustering)
results
colnames(resu?ts)<-"Cluster"
results$People<-rownames(results)
PCAorginal$People<-rownames(PCAorginal)
PCAorginal<-merge(PCAorginal,results, by="People")
rownames(PCAorginal)<-PCAorginal$People

with(PCAorginal, aggregate(PCAorginal[,1:19] , by=list(Cluster) , FUN=summa?y))
PCAorginal[PCAorginal$People==pam_fit$medoids,]


#PAM nad PCA koji je prethodno procesuiran
set.seed(1)
gower_dist<-daisy(PCAnovi, metric="gower")
summary(gower_dist)
gower_mat <- as.matrix(gower_dist)
PCAnovi[which(gower_mat==min(gower_mat[gower_mat!?0]),arr.ind=TRUE)[1, ], ]
PCAnovi[which(gower_mat==max(gower_mat),arr.ind = TRUE)[1, ], ]

#best k
sil_width<-c(NA)
for(i in 2:10){
  pam_fit<-pam(gower_dist, diss = TRUE, k=i)
  sil_width[i] <- pam_fit$silinfo$avg.width
}

plot(1:10, sil_width, xlab = "Br?j klastera", ylab = "Silouetthe")
lines(1:10, sil_width)

pam_fit<-pam(gower_dist, diss = TRUE, k=3)
results<-as.data.frame(pam_fit$clustering)
results
colnames(results)<-"Cluster"
results$People<-rownames(results)
PCAnovi$People<-rownames(PCAnovi)
PCAnovi?-merge(PCAnovi,results, by="People")
rownames(PCAnovi)<-PCAnovi$People

with(PCAnovi, aggregate(PCAnovi[,1:19] , by=list(Cluster) , FUN=summary))

PCAnovi[PCAnovi$People==pam_fit$medoids,]

#Iscrtavanje interesantnih osobina dataseta
boxplot(PCAnovi$Weight?PCAnovi$Cluster)
boxplot(PCAnovi$Height~PCAnovi$Cluster)
boxplot(PCAnovi$TUE~PCAnovi$Cluster)

#k-means nad procesuiranim datasetom

set.seed(123)

res.nbclust <- NbClust(data=PCAnovi, distance = "euclidean", min.nc = 2, max.nc = 18, method = "kmeans", ind?x ="all")
fviz_nbclust(res.nbclust) + theme_minimal() + ggtitle("NbClust's optimal number of clusters")

fviz_nbclust(PCAnovi, kmeans, method="wss", k.max=20) + ggtitle("the Elbow Method")
fviz_nbclust(PCAnovi, kmeans, method ="gap_stat", k.max=20) + ggtit?e("the Gap statistics")
fviz_nbclust(PCAnovi, kmeans, method ="silhouette", k.max=20) + ggtitle("the Silhouette")



