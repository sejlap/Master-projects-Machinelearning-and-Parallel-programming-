
setwd("/Users/User/Documents/ZadacaMU")
attritionTest<-read.csv("attrition_test.csv", header=T)


View(attritionTest)

#posto vidimo da imamo nekonzistentnih atributa izvrsit cemo transformaciju u konzistentne atribute

attritionTest$Education[attritionTest$Education == 1] = "Below College"
attritionTest$Education[attritionTest$Education == 4] = "Master"
attritionTest$Education[attritionTest$Education == 5] = "Doctor"

attritionTest$EnvironmentSatisfaction[attritionTest$EnvironmentSatisfaction == 1] = "Low"
attritionTest$EnvironmentSatisfaction[attritionTest$EnvironmentSatisfaction == 2] = "Medium"
attritionTest$EnvironmentSatisfaction[attritionTest$EnvironmentSatisfaction == 3] = "High"

attritionTest$JobInvolvement[attritionTest$JobInvolvement == 2] = "Medium"
attritionTest$JobInvolvement[attritionTest$JobInvolvement == 4] = "Very High"

attritionTest$JobLevel[attritionTest$JobLevel == 1] = "One"
attritionTest$JobLevel[attritionTest$JobLevel == 2] = "Two"
attritionTest$JobLevel[attritionTest$JobLevel == 3] = "Three"
attritionTest$JobLevel[attritionTest$JobLevel == 4] = "Four"
attritionTest$JobLevel[attritionTest$JobLevel == 5] = "Five"

attritionTest$JobSatisfaction[attritionTest$JobSatisfaction == 1] = "Low"
attritionTest$JobSatisfaction[attritionTest$JobSatisfaction == 3] = "High"
attritionTest$JobSatisfaction[attritionTest$JobSatisfaction == 4] = "Very High"

attritionTest$PerformanceRating[attritionTest$PerformanceRating == 1] = "Low"
attritionTest$PerformanceRating[attritionTest$PerformanceRating == 2] = "Good"
attritionTest$PerformanceRating[attritionTest$PerformanceRating == 3] = "Excellent"
attritionTest$PerformanceRating[attritionTest$PerformanceRating == 4] = "Outstanding"

attritionTest$RelationshipSatisfaction[attritionTest$RelationshipSatisfaction == 1] = "Low"
attritionTest$RelationshipSatisfaction[attritionTest$RelationshipSatisfaction == 2] = "Medium"
attritionTest$RelationshipSatisfaction[attritionTest$RelationshipSatisfaction == 3] = "High"
attritionTest$RelationshipSatisfaction[attritionTest$RelationshipSatisfaction == 4] = "VeryHigh"
attritionTest$StockOptionLevel[attritionTest$StockOptionLevel == 'Zero'] = "0"

#promjena u numericke vrijednosti
attritionTest$StockOptionLevel<-as.numeric(attritionTest$StockOptionLevel)
attritionTest$TrainingTimesLastYear<-as.numeric(attritionTest$TrainingTimesLastYear)
attritionTest$PercentSalaryHike<-as.numeric(attritionTest$PercentSalaryHike)


#izbacivanje StandardHours i Over18 zato sto su kontante i ne doprinose predikciji

attritionTest <- subset(attritionTest, select = -c(StandardHours,Over18))

#--------dodatno ciscenje ---------
library(eeptools)
Age <- floor(age_calc(as.Date(attritionTest$BirthDate), units="years"))
attritionTest <- data.frame(attritionTest, Age)


attritionTest<- attritionTest [, -c(1,9,10)]
attritionTest<- attritionTest [, -c(31)]

View(attritionTest)
##########################################################################################################


#Zadatak 3

#Provjeravanje coverage-a
library(rpart)
library(rattle)

pravila<- rpart(kfold_c50,data=attritionTest, cp=0.07)
asRules(pravila)

