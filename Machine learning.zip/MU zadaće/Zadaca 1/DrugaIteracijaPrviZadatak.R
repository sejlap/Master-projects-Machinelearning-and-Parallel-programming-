#ucitavanje dataseta
setwd("/Users/User/Documents/ZadacaMU")
attrition<-read.csv("attrition_train.csv", header=T)
#biblioteke
library(e1071) 
library(tree)
library(caret)
library(C50)
library(ipred)
library(rpart)
library(randomForest)
library(gbm)
library(ROSE)
library(eeptools)
#tipovi varijabli
str(attrition)

#transformaciju u konzistentne atribute

attrition$Education[attrition$Education == 1] = "Below College"
attrition$Education[attrition$Education == 4] = "Master"
attrition$Education[attrition$Education == 5] = "Doctor"

attrition$EnvironmentSatisfaction[attrition$EnvironmentSatisfaction == 1] = "Low"
attrition$EnvironmentSatisfaction[attrition$EnvironmentSatisfaction == 2] = "Medium"
attrition$EnvironmentSatisfaction[attrition$EnvironmentSatisfaction == 3] = "High"

attrition$JobInvolvement[attrition$JobInvolvement == 2] = "Medium"
attrition$JobInvolvement[attrition$JobInvolvement == 4] = "Very High"

attrition$JobLevel[attrition$JobLevel == 1] = "One"
attrition$JobLevel[attrition$JobLevel == 2] = "Two"
attrition$JobLevel[attrition$JobLevel == 3] = "Three"
attrition$JobLevel[attrition$JobLevel == 4] = "Four"
attrition$JobLevel[attrition$JobLevel == 5] = "Five"

attrition$JobSatisfaction[attrition$JobSatisfaction == 1] = "Low"
attrition$JobSatisfaction[attrition$JobSatisfaction == 3] = "High"
attrition$JobSatisfaction[attrition$JobSatisfaction == 4] = "Very High"

attrition$PerformanceRating[attrition$PerformanceRating == 1] = "Low"
attrition$PerformanceRating[attrition$PerformanceRating == 2] = "Good"
attrition$PerformanceRating[attrition$PerformanceRating == 3] = "Excellent"
attrition$PerformanceRating[attrition$PerformanceRating == 4] = "Outstanding"

attrition$RelationshipSatisfaction[attrition$RelationshipSatisfaction == 1] = "Low"
attrition$RelationshipSatisfaction[attrition$RelationshipSatisfaction == 2] = "Medium"
attrition$RelationshipSatisfaction[attrition$RelationshipSatisfaction == 3] = "High"
attrition$RelationshipSatisfaction[attrition$RelationshipSatisfaction == 4] = "VeryHigh"
attrition$StockOptionLevel[attrition$StockOptionLevel == 'Zero'] = "0"

#promjena u numericke vrijednosti
attrition$StockOptionLevel<-as.numeric(attrition$StockOptionLevel)
attrition$TrainingTimesLastYear<-as.numeric(attrition$TrainingTimesLastYear)
attrition$PercentSalaryHike<-as.numeric(attrition$PercentSalaryHike)


#nedostajuce vrijednosti

count_NA <- sapply(attrition, function(x) sum(length(which(is.na(x)))))
count_NA <- data.frame(count_NA)
count_NA
#popunavanje numerickih atributa sa mean 
perSalaryMean<-mean(attrition$PercentSalaryHike, na.rm = TRUE)
attrition$PercentSalaryHike[is.na(attrition$PercentSalaryHike )] <- perSalaryMean
trainLastYear<-mean(attrition$TrainingTimesLastYear, na.rm = TRUE)
attrition$TrainingTimesLastYear[is.na(attrition$TrainingTimesLastYear )] <- trainLastYear


##########################################################################################################

#DRUGA ITERACIJA

#dodatne transformacije nad podacima
#popunjavanje kategorickih varijabli koristenjem predikcije
test<-attrition
kategoricke<- test [, -c(1,4,6,9,10,13,19,20,21,22,24,27,28,29,30,32,33,34,35)]

View(kategoricke)

y <- rpart(kategoricke$JobRole~ kategoricke$Attrition + kategoricke$Department + 
             kategoricke$EducationField,data=kategoricke[!is.na(kategoricke$JobRole ),],
           method="class",na.action = na.omit)
pred<-predict(y,kategoricke[is.na(kategoricke$JobRole ),])
attrition$JobRole<- as.factor(attrition$JobRole)
#popunjavanje
for (i in 1:nrow(attrition)){
  if(is.na(attrition$JobRole[i])){
    red<-pred[i,]
    index<-which.max(red)
    attrition$JobRole[i]<-levels(attrition$JobRole)[index]
  }
}

#department
y <- rpart(kategoricke$Department ~ kategoricke$Attrition + kategoricke$EducationField + 
             kategoricke$JobRole + kategoricke$WorkLifeBalance, 
           data=kategoricke[!is.na(kategoricke$Department),], method="class",na.action = na.omit)
pred<-predict(y,kategoricke[is.na(kategoricke$Department),])

attrition$Department<- as.factor(attrition$Department)
#popunjavanje department
for (i in 1:nrow(attrition)){
  if(is.na(attrition$Department[i])){
    red<-pred[i,]
    index<-which.max(red)
    attrition$Department[i]<-levels(attrition$Department)[index]
  }
}


#education field

y <- rpart(kategoricke$EducationField ~ kategoricke$Attrition + 
             kategoricke$Department + kategoricke$Education + kategoricke$JobRole, 
           data=kategoricke[!is.na(kategoricke$EducationField ),],method="class",na.action = na.omit)
pred<-predict(y,kategoricke[is.na(kategoricke$EducationField ),])

attrition$EducationField<- as.factor(attrition$EducationField)
#popunjavanje Education Field
for (i in 1:nrow(attrition)){
  if(is.na(attrition$EducationField[i])){
    red<-pred[i,]
    index<-which.max(red)
    attrition$EducationField[i]<-levels(attrition$EducationField)[index]
  }
}

#izbacivanje StandardHours i Over18 zato sto su kontante i ne doprinose predikciji

attrition <- subset(attrition, select = -c(StandardHours,Over18))
View(attrition)


#outliers

#######################################
Q <- quantile(attrition$YearsSinceLastPromotion, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attrition$YearsSinceLastPromotion)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attrition <- subset(attrition, attrition$YearsSinceLastPromotion > (Q[1] - 1.5*iqr) & attrition$YearsSinceLastPromotion< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za HourlyRate atribut ########################################
Q <- quantile(attrition$HourlyRate, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attrition$HourlyRate)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attrition <- subset(attrition, attrition$HourlyRate > (Q[1] - 1.5*iqr) & attrition$HourlyRate< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za MonthlyIncome atribut ########################################
Q <- quantile(attrition$MonthlyIncome, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attrition$MonthlyIncome)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attrition <- subset(attrition, attrition$MonthlyIncome > (Q[1] - 1.5*iqr) & attrition$MonthlyIncome< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za StockOptionLevel atribut ########################################
Q <- quantile(attrition$StockOptionLevel, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attrition$StockOptionLevel)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attrition <- subset(attrition, attrition$StockOptionLevel > (Q[1] - 1.5*iqr) & attrition$StockOptionLevel< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za TotalWorkingYears atribut ########################################
Q <- quantile(attrition$TotalWorkingYears, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attrition$TotalWorkingYears)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attrition <- subset(attrition, attrition$TotalWorkingYears > (Q[1] - 1.5*iqr) & attrition$TotalWorkingYears< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za TrainingTimesLastYear atribut ########################################
Q <- quantile(attrition$TrainingTimesLastYear, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attrition$TrainingTimesLastYear)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attrition <- subset(attrition, attrition$TrainingTimesLastYear > (Q[1] - 1.5*iqr) & attrition$TrainingTimesLastYear< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za YearsAtCompany atribut ########################################
Q <- quantile(attrition$YearsAtCompany, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attrition$YearsAtCompany)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attrition <- subset(attrition, attrition$YearsAtCompany > (Q[1] - 1.5*iqr) & attrition$YearsAtCompany< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za YearsInCurrentRole atribut ########################################
Q <- quantile(attrition$YearsInCurrentRole, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attrition$YearsInCurrentRole)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attrition <- subset(attrition, attrition$YearsInCurrentRole > (Q[1] - 1.5*iqr) & attrition$YearsInCurrentRole< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za YearsWithCurrManager atribut ########################################
Q <- quantile(attrition$YearsWithCurrManager, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attrition$YearsWithCurrManager)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attrition <- subset(attrition, attrition$YearsWithCurrManager > (Q[1] - 1.5*iqr) & attrition$YearsWithCurrManager< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za NumCompaniesWorked atribut ########################################
Q <- quantile(attrition$NumCompaniesWorked, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attrition$NumCompaniesWorked)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attrition <- subset(attrition, attrition$NumCompaniesWorked > (Q[1] - 1.5*iqr) & attrition$NumCompaniesWorked< (Q[2]+1.5*iqr))

#balansiranje
table(attrition$Attrition)
prop.table(table(attrition$Attrition))

#oversampling i undersampling
attrition<-ovun.sample(Attrition~., data = attrition, method="under", N=500, seed = 1)$data
#attrition<-ovun.sample(Attrition~., data = attrition, method="over", N=874)$data
table(attrition$Attrition)

#--------dodatno ciscenje ---------
Age <- floor(age_calc(as.Date(attrition$BirthDate), units="years"))
attrition <- data.frame(attrition, Age)
#izbacivanje nepotrebnih kolona X, EmployeeCount, EmployeeNumber i BirthDate
attrition<- attrition [, -c(1,9,10)]
attrition<- attrition [, -c(31)]
#Druga iteracija metode

smp_size <- floor(0.7 * nrow(attrition))
set.seed(123)
train_ind <- sample(1:(nrow(attrition)), size = smp_size)

train_z1 <- attrition[train_ind, ]
test_z1 <- attrition[-train_ind, ]

#tree
tree <- tree(as.factor(Attrition)~., train_z1)
tree_predict <- predict(tree, test_z1, type = "class")
confusionMatrix(tree_predict, as.factor(test_z1$Attrition), positive = "Yes")

#c50

train_z1$HourlyRate<-as.factor(train_z1$HourlyRate)
test_z1$HourlyRate<-as.factor(test_z1$HourlyRate)
tree_c50 <- C5.0(as.factor(Attrition)~., train_z1)
c50_predict <- predict(tree_c50, test_z1, type = "class")
confusionMatrix(c50_predict, as.factor(test_z1$Attrition), positive = "Yes")

#bagging
tree_bag <- bagging(as.factor(Attrition)~., train_z1,coob = TRUE)
bag_predict <- predict(tree_bag, test_z1, type = "class")
confusionMatrix(bag_predict, as.factor(test_z1$Attrition), positive = "Yes")

#randomforest
train_z1 <- attrition[train_ind, ]
test_z1 <- attrition[-train_ind, ]

tree_rf <- randomForest(as.factor(Attrition)~., train_z1, importance = TRUE)
rf_predict <- predict(tree_rf, test_z1, type = "class")
confusionMatrix(rf_predict, as.factor(test_z1$Attrition), positive = "Yes")

#gbm
tree_gbm <- gbm(as.factor(Attrition)~., data=train_z1)
tree_predict <- predict(tree_gbm, test_z1, type = "class")
confusionMatrix(tree_predict, as.factor(test_z1$Attrition), positive = "Yes")


#metode evaluacije 

#k-fold unakrsna validacija
set.seed(123) 
train_control_kfold <- trainControl(method = "cv", number = 10, classProbs = TRUE, savePredictions = "final")

#Funkcija Tree
kfold_tree <- train(Attrition~., attrition, trControl = train_control_kfold,  method = "ctree")
confusionMatrix(kfold_tree$pred$pred, kfold_tree$pred$obs, positive = "Yes")

#Funkcija C50
kfold_c50 <- train(as.factor(Attrition)~., attrition, trControl = train_control_kfold, method = "C5.0")
confusionMatrix(kfold_c50$pred$pred, kfold_c50$pred$obs, positive = "Yes")
#Funckija random forest
kfold_rf <- train(Attrition~., attrition, trControl = train_control_kfold, method = "cforest")
confusionMatrix(kfold_rf$pred$pred, kfold_rf$pred$obs, positive = "Yes")
#Funkcija Bagging
kfold_bag <- train(Attrition~., attrition, trControl = train_control_kfold, method = "treebag")
confusionMatrix(kfold_bag$pred$pred, kfold_bag$pred$obs, positive = "Yes")
#gbm
kfold_gbm <- train(Attrition~., attrition, trControl = train_control_kfold, method = "gbm", verbose = FALSE)
confusionMatrix(kfold_gbm$pred$pred, kfold_gbm$pred$obs, positive = "Yes")

#Bootstrapping
set.seed(123)
train_control_boot <- trainControl(method = "boot", number = 10, classProbs = TRUE, savePredictions = "final")

#Funkcija Tree
boot_tree <- train(Attrition~., attrition, trControl = train_control_boot, method = "ctree")
confusionMatrix(boot_tree$pred$pred, boot_tree$pred$obs, positive = "Yes")

#Funkcija C50
boot_c50 <- train(Attrition~., attrition, trControl = train_control_boot, method = "C5.0")
confusionMatrix(boot_c50$pred$pred, boot_c50$pred$obs, positive = "Yes")

#Funkcija Bagging
boot_bag <- train(Attrition~., attrition, trControl = train_control_boot, method = "treebag")
confusionMatrix(boot_bag$pred$pred, boot_bag$pred$obs, positive = "Yes")

#Funkcija Random Forest
boot_rf <- train(Attrition~., attrition, trControl = train_control_boot, method = "cforest")
confusionMatrix(boot_rf$pred$pred, boot_rf$pred$obs, positive = "Yes")
#Funkcija GBM
boot_gbm <- train(Attrition~., attrition, trControl = train_control_boot, method = "gbm", verbose = FALSE)
confusionMatrix(boot_gbm$pred$pred, boot_gbm$pred$obs, positive = "Yes")

