
setwd("/Users/User/Documents/ZadacaMU")
attritionTest<-read.csv("attrition_test.csv", header=T)


#posto vidimo da imamo nekonzistentnih atributa izvrsit cemo transformaciju u konzistentne atribute

attritionTest$Education[attritionTest$Education == 1] = "Below College"
attritionTest$Education[attritionTest$Education == 4] = "Master"
attritionTest$Education[attritionTest$Education == 5] = "Doctor"

attritionTest$EnvironmentSatisfaction[attritionTest$EnvironmentSatisfaction == 1] = "Low"
attritionTest$EnvironmentSatisfaction[attritionTest$EnvironmentSatisfaction == 2] = "Medium"
attritionTest$EnvironmentSatisfaction[attritionTest$EnvironmentSatisfaction == 3] = "High"

attritionTest$JobInvolvement[attritionTest$JobInvolvement == 2] = "Medium"
attritionTest$JobInvolvement[attritionTest$JobInvolvement == 4] = "Very High"

attritionTest$JobLevel[attritionTest$JobLevel == 1] = "One"
attritionTest$JobLevel[attritionTest$JobLevel == 2] = "Two"
attritionTest$JobLevel[attritionTest$JobLevel == 3] = "Three"
attritionTest$JobLevel[attritionTest$JobLevel == 4] = "Four"
attritionTest$JobLevel[attritionTest$JobLevel == 5] = "Five"

attritionTest$JobSatisfaction[attritionTest$JobSatisfaction == 1] = "Low"
attritionTest$JobSatisfaction[attritionTest$JobSatisfaction == 3] = "High"
attritionTest$JobSatisfaction[attritionTest$JobSatisfaction == 4] = "Very High"

attritionTest$PerformanceRating[attritionTest$PerformanceRating == 1] = "Low"
attritionTest$PerformanceRating[attritionTest$PerformanceRating == 2] = "Good"
attritionTest$PerformanceRating[attritionTest$PerformanceRating == 3] = "Excellent"
attritionTest$PerformanceRating[attritionTest$PerformanceRating == 4] = "Outstanding"

attritionTest$RelationshipSatisfaction[attritionTest$RelationshipSatisfaction == 1] = "Low"
attritionTest$RelationshipSatisfaction[attritionTest$RelationshipSatisfaction == 2] = "Medium"
attritionTest$RelationshipSatisfaction[attritionTest$RelationshipSatisfaction == 3] = "High"
attritionTest$RelationshipSatisfaction[attritionTest$RelationshipSatisfaction == 4] = "VeryHigh"
attritionTest$StockOptionLevel[attritionTest$StockOptionLevel == 'Zero'] = "0"

#promjena u numericke vrijednosti
attritionTest$StockOptionLevel<-as.numeric(attritionTest$StockOptionLevel)
attritionTest$TrainingTimesLastYear<-as.numeric(attritionTest$TrainingTimesLastYear)
attritionTest$PercentSalaryHike<-as.numeric(attritionTest$PercentSalaryHike)


#izbacivanje StandardHours i Over18 zato sto su kontante i ne doprinose predikciji

attritionTest <- subset(attritionTest, select = -c(StandardHours,Over18))
View(attritionTest)

#outliers
#######################################
Q <- quantile(attritionTest$YearsSinceLastPromotion, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attritionTest$YearsSinceLastPromotion)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attritionTest <- subset(attritionTest, attritionTest$YearsSinceLastPromotion > (Q[1] - 1.5*iqr) & attritionTest$YearsSinceLastPromotion< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za HourlyRate atribut ########################################
Q <- quantile(attritionTest$HourlyRate, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attritionTest$HourlyRate)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attritionTest <- subset(attritionTest, attritionTest$HourlyRate > (Q[1] - 1.5*iqr) & attritionTest$HourlyRate< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za MonthlyIncome atribut ########################################
Q <- quantile(attritionTest$MonthlyIncome, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attritionTest$MonthlyIncome)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attritionTest <- subset(attritionTest, attritionTest$MonthlyIncome > (Q[1] - 1.5*iqr) & attritionTest$MonthlyIncome< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za StockOptionLevel atribut ########################################
Q <- quantile(attritionTest$StockOptionLevel, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attritionTest$StockOptionLevel)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attritionTest <- subset(attritionTest, attritionTest$StockOptionLevel > (Q[1] - 1.5*iqr) & attritionTest$StockOptionLevel< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za TotalWorkingYears atribut ########################################
Q <- quantile(attritionTest$TotalWorkingYears, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attritionTest$TotalWorkingYears)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attritionTest <- subset(attritionTest, attritionTest$TotalWorkingYears > (Q[1] - 1.5*iqr) & attritionTest$TotalWorkingYears< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za TrainingTimesLastYear atribut ########################################
Q <- quantile(attritionTest$TrainingTimesLastYear, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attritionTest$TrainingTimesLastYear)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attritionTest <- subset(attritionTest, attritionTest$TrainingTimesLastYear > (Q[1] - 1.5*iqr) & attritionTest$TrainingTimesLastYear< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za YearsAtCompany atribut ########################################
Q <- quantile(attritionTest$YearsAtCompany, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attritionTest$YearsAtCompany)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attritionTest <- subset(attritionTest, attritionTest$YearsAtCompany > (Q[1] - 1.5*iqr) & attritionTest$YearsAtCompany< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za YearsInCurrentRole atribut ########################################
Q <- quantile(attritionTest$YearsInCurrentRole, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attritionTest$YearsInCurrentRole)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attritionTest <- subset(attritionTest, attritionTest$YearsInCurrentRole > (Q[1] - 1.5*iqr) & attritionTest$YearsInCurrentRole< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za YearsWithCurrManager atribut ########################################
Q <- quantile(attritionTest$YearsWithCurrManager, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attritionTest$YearsWithCurrManager)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attritionTest <- subset(attritionTest, attritionTest$YearsWithCurrManager > (Q[1] - 1.5*iqr) & attritionTest$YearsWithCurrManager< (Q[2]+1.5*iqr))

############################# Otklanjanje outliersa za NumCompaniesWorked atribut ########################################
Q <- quantile(attritionTest$NumCompaniesWorked, probs=c(.25, .75), na.rm = FALSE)
iqr <- IQR(attritionTest$NumCompaniesWorked)
up <- Q[2]+1.5*iqr # Upper Range 
low<- Q[1]-1.5*iqr # Lower Range
attritionTest <- subset(attritionTest, attritionTest$NumCompaniesWorked > (Q[1] - 1.5*iqr) & attritionTest$NumCompaniesWorked< (Q[2]+1.5*iqr))



#--------dodatno ciscenje ---------
library(eeptools)
Age <- floor(age_calc(as.Date(attritionTest$BirthDate), units="years"))
attritionTest <- data.frame(attritionTest, Age)


attritionTest<- attritionTest [, -c(1,9,10)]
attritionTest<- attritionTest [, -c(31)]

View(attritionTest)
##########################################################################################################


#Evaluacija modela k fold

attrition_gbm <- predict(kfold_gbm, attritionTest)
confusionMatrix(attrition_gbm, as.factor(attritionTest$Attrition), positive = "Yes")







