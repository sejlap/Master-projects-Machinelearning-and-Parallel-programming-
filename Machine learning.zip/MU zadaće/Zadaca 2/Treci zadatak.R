library(e1071)
library(caret)
library(ISLR)
library(MASS)
library(RCurl)
library(nnet)

setwd("C:/Users/User/Documents/MU_Zadaca2")
house_price<-read.csv("housepricedata.csv", header=T)

#tipovi atributa i njihova distribucija
str(house_price)
summary(hous?_price)

boxplot(house_price$LotArea)
skewness(house_price$LotArea) 

boxplot(house_price$OverallQual)
skewness(house_price$OverallQual) 

boxplot(house_price$OverallCond)
skewness(house_price$OverallCond) 

boxplot(house_price$TotalBsmtSF)
skewness(house_?rice$TotalBsmtSF)

boxplot(house_price$FullBath)
skewness(house_price$FullBath) 

boxplot(house_price$HalfBath)
skewness(house_price$HalfBath) 

boxplot(house_price$BedroomAbvGr)
skewness(house_price$BedroomAbvGr)

boxplot(house_price$TotRmsAbvGrd)
skewnes?(house_price$TotRmsAbvGrd) 

boxplot(house_price$Fireplaces)
skewness(house_price$Fireplaces) 


boxplot(house_price$GarageArea)
skewness(house_price$GarageArea) 

boxplot(house_price$AboveMedianPrice)
skewness(house_price$AboveMedianPrice) 

#provjera ned?stajucih vrijednosti
count_NA <- sapply(house_price, function(x) sum(length(which(is.na(x)))))
count_NA <- data.frame(count_NA)
count_NA
#neddostajucih vrijednosti nema
#provjera balansiranosti
prop.table(table(house_price$AboveMedianPrice)) 
table(house_p?ice$AboveMedianPrice)

#podjela na trening i testni set
set.seed(123)
train<-sample(nrow(house_price),0.7*nrow(house_price))
house.test<-house_price[-train,]
house.train<-house_price[train,]

#LDA 
lda.fit<-lda(AboveMedianPrice~.,data=house.train)
summary(?da.fit)
lda.pred<-predict(lda.fit, house.test)
lda.class<-lda.pred$class
confusionMatrix(lda.class, as.factor(house.test$AboveMedianPrice))

#QDA
qda.fit<-qda(AboveMedianPrice~.,data=house.train)
qda.pred<-predict(qda.fit, house.test)
qda.class<-qda.pred$c?ass
confusionMatrix(qda.class,as.factor(house.test$AboveMedianPrice))

#neuronske mreze

modelnnet<-nnet(as.factor(AboveMedianPrice)~., data=house.train, size=10,decay=0.005,maxit=500)
summary(modelnnet)

#klasifikacija test set-a (bez klase)
predictions<-?redict(modelnnet,house.test[, -11],type="class")
confusionMatrix(as.factor(predictions), as.factor(house.test$AboveMedianPrice))

#kreiranje tabele sa predvi�enim i stvarnim klasama
mtab <- table(predictions,house.test$AboveMedianPrice)
#funkcija za mjeren?e preciznosti u %
accuracy <- function(x){sum(diag(x)/(sum(rowSums(x)))) * 100}
accuracy(mtab) 



