getwd()
setwd("C:/Users/User/Documents/Fax/4. godina/1. semestar/MU/Zadaca 1/Attrition_data")
attrition<-read.csv("attrition_train.csv", header=T)

#biblioteke
library(e1071) 
library(tree)
library(caret)
library(C50)
library(ipred)
library(rpart)
library(randomForest)
library(gbm)
library(ROSE)
library(eeptools)
library(StatMatch)
library(ROCR)

attrition$Education[attrition$Education == 1] = "Below College"
attrition$Education[attrition$Education == 4] = "Master"
attrition$Education[attrition$Education == 5] = "Doctor"

attrition$EnvironmentSatisfaction[attrition$EnvironmentSatisfaction == 1] = "Low"
attrition$EnvironmentSatisfaction[attrition$EnvironmentSatisfaction == 2] = "Medium"
attrition$EnvironmentSatisfaction[attrition$EnvironmentSatisfaction == 3] = "High"

attrition$JobInvolvement[attrition$JobInvolvement == 2] = "Medium"
attrition$JobInvolvement[attrition$JobInvolvement == 4] = "Very High"

attrition$JobLevel[attrition$JobLevel == 1] = "One"
attrition$JobLevel[attrition$JobLevel == 2] = "Two"
attrition$JobLevel[attrition$JobLevel == 3] = "Three"
attrition$JobLevel[attrition$JobLevel == 4] = "Four"
attrition$JobLevel[attrition$JobLevel == 5] = "Five"

attrition$JobSatisfaction[attrition$JobSatisfaction == 1] = "Low"
attrition$JobSatisfaction[attrition$JobSatisfaction == 3] = "High"
attrition$JobSatisfaction[attrition$JobSatisfaction == 4] = "Very High"

attrition$PerformanceRating[attrition$PerformanceRating == 1] = "Low"
attrition$PerformanceRating[attrition$PerformanceRating == 2] = "Good"
attrition$PerformanceRating[attrition$PerformanceRating == 3] = "Excellent"
attrition$PerformanceRating[attrition$PerformanceRating == 4] = "Outstanding"

attrition$RelationshipSatisfaction[attrition$RelationshipSatisfaction == 1] = "Low"
attrition$RelationshipSatisfaction[attrition$RelationshipSatisfaction == 2] = "Medium"
attrition$RelationshipSatisfaction[attrition$RelationshipSatisfaction == 3] = "High"
attrition$RelationshipSatisfaction[attrition$RelationshipSatisfaction == 4] = "VeryHigh"
attrition$StockOptionLevel[attrition$StockOptionLevel == 'Zero'] = "0"

attrition$StockOptionLevel<-as.numeric(attrition$StockOptionLevel)
attrition$TrainingTimesLastYear<-as.numeric(attrition$TrainingTimesLastYear)
attrition$PercentSalaryHike<-as.numeric(attrition$PercentSalaryHike)



#nedostajuce vrijednosti

#popunavanje numerickih atributa sa mean 
perSalaryMean<-mean(attrition$PercentSalaryHike, na.rm = TRUE)
attrition$PercentSalaryHike[is.na(attrition$PercentSalaryHike )] <- perSalaryMean
trainLastYear<-mean(attrition$TrainingTimesLastYear, na.rm = TRUE)
attrition$TrainingTimesLastYear[is.na(attrition$TrainingTimesLastYear )] <- trainLastYear

#popunjavanje kategorickih varijabli koristenjem predikcije
test<-attrition
kategoricke<- test [, -c(1,4,6,9,10,13,19,20,21,22,24,27,28,29,30,32,33,34,35)]

y <- rpart(kategoricke$JobRole~ kategoricke$Attrition + kategoricke$Department + 
             kategoricke$EducationField,data=kategoricke[!is.na(kategoricke$JobRole ),],
           method="class",na.action = na.omit)
pred<-predict(y,kategoricke[is.na(kategoricke$JobRole ),])
attrition$JobRole<- as.factor(attrition$JobRole)
#popunjavanje
for (i in 1:nrow(attrition)){
  if(is.na(attrition$JobRole[i])){
    red<-pred[i,]
    index<-which.max(red)
    attrition$JobRole[i]<-levels(attrition$JobRole)[index]
  }
}

#department
y <- rpart(kategoricke$Department ~ kategoricke$Attrition + kategoricke$EducationField + 
             kategoricke$JobRole + kategoricke$WorkLifeBalance, 
           data=kategoricke[!is.na(kategoricke$Department),], method="class",na.action = na.omit)
pred<-predict(y,kategoricke[is.na(kategoricke$Department),])

attrition$Department<- as.factor(attrition$Department)
#popunjavanje department
for (i in 1:nrow(attrition)){
  if(is.na(attrition$Department[i])){
    red<-pred[i,]
    index<-which.max(red)
    attrition$Department[i]<-levels(attrition$Department)[index]
  }
}


#education field

y <- rpart(kategoricke$EducationField ~ kategoricke$Attrition + 
             kategoricke$Department + kategoricke$Education + kategoricke$JobRole, 
           data=kategoricke[!is.na(kategoricke$EducationField ),],method="class",na.action = na.omit)
pred<-predict(y,kategoricke[is.na(kategoricke$EducationField ),])

attrition$EducationField<- as.factor(attrition$EducationField)
#popunjavanje Education Field
for (i in 1:nrow(attrition)){
  if(is.na(attrition$EducationField[i])){
    red<-pred[i,]
    index<-which.max(red)
    attrition$EducationField[i]<-levels(attrition$EducationField)[index]
  }
}

#izbacivanje StandardHours i Over18 zato sto su kontante i ne doprinose predikciji

attrition <- subset(attrition, select = -c(StandardHours,Over18))


# OUTLIERSI 
attrition$YearsSinceLastPromotion <- log(attrition$YearsSinceLastPromotion- (min(attrition$YearsSinceLastPromotion)-1))
attrition$HourlyRate <- log(attrition$HourlyRate - (min(attrition$HourlyRate)-1))
attrition$MonthlyIncome <- log(attrition$MonthlyIncome- (min(attrition$MonthlyIncome)-1))
attrition$StockOptionLevel <- log(attrition$StockOptionLevel - (min(attrition$StockOptionLevel)-1))
attrition$TotalWorkingYears <- log(attrition$TotalWorkingYears - (min(attrition$TotalWorkingYears)-1))
attrition$TrainingTimesLastYear <- log(attrition$TrainingTimesLastYear - (min(attrition$TrainingTimesLastYear)-1))
attrition$YearsAtCompany <- log(attrition$YearsAtCompany  - (min(attrition$YearsAtCompany )-1))
attrition$YearsInCurrentRole <- log(attrition$YearsInCurrentRole- (min(attrition$YearsInCurrentRole)-1))
attrition$YearsWithCurrManager <- log(attrition$YearsWithCurrManager- (min(attrition$YearsWithCurrManager)-1))
attrition$NumCompaniesWorked <- log(attrition$NumCompaniesWorked- (min(attrition$NumCompaniesWorked)-1))

# balansiranje - novo

smp_size <- floor(0.7 * nrow(attrition))
set.seed(123)
train_ind <- sample(1:(nrow(attrition)), size = smp_size)

train_z1 <- attrition[train_ind, ]
test_z1 <- attrition[-train_ind, ]

#oversampling i undersampling
table(attrition$Attrition)
prop.table(table(attrition$Attrition))
attrition<-ovun.sample(Attrition~., data = train_z1, method="under", N=700, seed = 1)$data
table(attrition$Attrition)


#--------dodatno ciscenje ---------
Age <- floor(age_calc(as.Date(attrition$BirthDate), units="years"))
attrition <- data.frame(attrition, Age)
#izbacivanje nepotrebnih kolona X, EmployeeCount, EmployeeNumber i BirthDate
attrition<- attrition [, -c(1,9,10)]
attrition<- attrition [, -c(31)]


#############################

#Postavljanje Attrition na posljednju poziciju
attrition2 <- attrition[, -1]
attrition <- data.frame(attrition2, attrition$Attrition)
colnames(attrition)[31] <- "Attrition"
attach(attrition)

smp_size <- floor(0.7 * nrow(attrition))
set.seed(123)
train_ind <- sample(1:(nrow(attrition)), size = smp_size)

train_z <- attrition[train_ind, ]
test_z <- attrition

## KNN
knngow_fun <- function (train,test,k) 
{
  # library(StatMatch)
  p=dim(train)[2]
  ntest=dim(test)[1]
  ntrain=dim(train)[1]
  classes=rep(0,ntest)
  if(ntest==ntrain)
  {     
    for(i in 1:ntest)
    { 
      tempo=order(gower.dist(test[i,-p],train[-i,-p]))[1:k]
      classes[i]=moda(train[tempo,p])[1]
    }
  }
  else 
  {
    for(i in 1:ntest)
    {
      tempo=order(StatMatch::gower.dist(test[i,-p],train[,-p]))[1:k] 
      classes[i]=moda(train[tempo,p])[1]
    }
  }
  classes
}

moda <- structure(function (x, na.rm = TRUE) 
{
  if (na.rm == TRUE) m1 = rev(sort(table(x[])))
  else m1 = rev(sort(table(x, exclude = NULL)))
  
  moda = names(m1[m1 == m1[1]])
  if (is(x, "numeric")) moda = as.numeric(moda)
  return(moda)
}, source = c("function(x,na.rm=TRUE)", "{", "  ", "#Function that finds the mode of vector x", 
              "", "  if(na.rm==TRUE) m1=rev(sort(table(x[])))", "    else m1=rev(sort(table(x,exclude=NULL)))", 
              "  moda=names(m1[m1==m1[1]])", "  if (is(x,\"numeric\")) moda=as.numeric(moda)", 
              "  return(moda)", "}"))


knn_predict <- knngow_fun(train_z, test_z, 10)
knn_predict <- as.factor(knn_predict)
confusionMatrix(knn_predict, as.factor(test_z$Attrition), positive="Yes")

# ROC kriva za knn
knn_prediction <- prediction(as.numeric(knn_predict), test_z$Attrition)
plot(performance(knn_prediction, measure = "tpr", x.measure = "fpr"), colorize = TRUE)



## Logisticka regresija
model_lr <- glm(as.factor(Attrition)~., family=binomial(link='logit'), train_z)
pred_lr <- predict(model_lr, test_z, type = "response")
library(plyr)
temp1 <- as.numeric(pred_lr > 0.5)
temp2 <- mapvalues(temp1, from = c(0, 1), to = c("No","Yes"))
confusionMatrix(as.factor(temp2), as.factor(test_z$Attrition), positive = "Yes")

#Logisticka regresija ROC kriva
pred_roc_lr <- prediction(pred_lr, test_z$Attrition)
plot(performance(pred_roc_lr, measure = "tpr", x.measure = "fpr"), colorize = TRUE)


## LDA
library(MASS)
library(caret)

model_lda <- lda(Attrition~., train_z)
pred_lda <- predict(model_lda,  test_z)
confusionMatrix(pred_lda$class, as.factor(test_z$Attrition), positive="Yes")

#LDA ROC kriva
pred_roc_lda <- prediction(pred_lda$posterior[,2], test_z$Attrition) 
plot(performance(pred_roc_lda, measure = "tpr", x.measure = "fpr"), colorize = TRUE)

#QDA


#qda_attrition<-train_z
#View(qda_attrition)
#qda_attrition$BusinessTravel<- as.numeric(qda_attrition$BusinessTravel)
#qda_attrition$Department<- as.numeric(qda_attrition$Department)
#qda_attrition$Education<- as.numeric(qda_attrition$Education)
#qda_attrition$EducationField<- as.numeric(qda_attrition$EducationField)
#qda_attrition$EnvironmentSatisfaction<- as.numeric(qda_attrition$EnvironmentSatisfaction)
#qda_attrition$Gender<- as.numeric(qda_attrition$Gender)
#qda_attrition$JobInvolvement<- as.numeric(qda_attrition$JobInvolvement)
#qda_attrition$JobLevel<- as.numeric(qda_attrition$JobLevel)
#qda_attrition$JobRole<- as.numeric(qda_attrition$JobRole)
#qda_attrition$JobSatisfaction<- as.numeric(qda_attrition$JobSatisfaction)
#qda_attrition$MaritalStatus<- as.numeric(qda_attrition$MaritalStatus)
#qda_attrition$OverTime<- as.numeric(qda_attrition$OverTime)
#qda_attrition$PerformanceRating<- as.numeric(qda_attrition$PerformanceRating)
#qda_attrition$RelationshipSatisfaction<- as.numeric(qda_attrition$RelationshipSatisfaction)
#qda_attrition$WorkLifeBalance<- as.numeric(qda_attrition$WorkLifeBalance)

#qdaattrition<-train_z
#qdaattrition <- subset(qdaattrition, select = -c(EducationField))


#BusinessTravel+ DailyRate +Department+DistanceFromHome +Education+EducationField +EnvironmentSatisfaction + Gender+HourlyRate +JobInvolvement+JobLevel + JobRole+JobSatisfaction + MaritalStatus+MonthlyIncome + MonthlyRate + NumCompaniesWorked + OverTime + PercentSalaryHike + PerformanceRating + RelationshipSatisfaction + StockOptionLevel + TotalWorkingYears + TrainingTimesLastYear + WorkLifeBalance +       
#YearsAtCompany  +  YearsInCurrentRole  + YearsSinceLastPromotion + YearsWithCurrManager + Age,train_z)


model_qda <- qda(as.factor(Attrition)~EducationField, train_z)
pred_qda <- predict(model_qda,  test_z)
confusionMatrix(pred_qda$class, as.factor(test_z$Attrition), positive="Yes")

#QDA ROC kriva
pred_roc_qda <- prediction(pred_qda$posterior[,2], test_z$Attrition) 
plot(performance(pred_roc_qda, measure = "tpr", x.measure = "fpr"), colorize = TRUE)

#SVM
library(e1071)
set.seed (123)
svmfit<-svm(as.factor(Attrition)~., data=train_z, kernel="linear", cost=1, scale=TRUE,  probability = TRUE)
pred_svm <- predict(svmfit, test_z, probability = TRUE)
confusionMatrix(pred_svm, as.factor(test_z$Attrition), positive = "Yes")

#SVM ROC kriva

roc_svm <- prediction(attr(pred_svm, "probabilities")[,2], test_z$Attrition)
plot(performance(roc_svm, measure = "tpr", x.measure = "fpr"), colorize = TRUE)


###### Evaluacija
#k-fold unakrsna validacija
set.seed(123) 
train_control_kfold <- trainControl(method = "cv", number = 10, classProbs = TRUE, savePredictions = "final")

#knn
kfold_knn <- train(Attrition~., attrition, trControl = train_control_kfold,  method = "knn")
confusionMatrix(kfold_knn$pred$pred, kfold_knn$pred$obs, positive = "Yes")
kfold_roc_knn <- prediction(as.numeric(kfold_knn$pred$pred), attrition$Attrition)
plot(performance(kfold_roc_knn, measure = "tpr", x.measure = "fpr"), colorize = TRUE)

#LDA
kfold_lda <- train(Attrition~., attrition, trControl = train_control_kfold, method = "lda")
confusionMatrix(kfold_lda$pred$pred, kfold_lda$pred$obs, positive = "Yes")
kfold_roc_lda <- prediction(as.numeric(kfold_lda$pred$pred), attrition$Attrition)
plot(performance(kfold_roc_lda, measure = "tpr", x.measure = "fpr"), colorize = TRUE)

#Logisticka regresija
kfold_lr <- train(Attrition~., attrition, trControl = train_control_kfold, method = "glm")
confusionMatrix(kfold_lr$pred$pred, kfold_lr$pred$obs, positive = "Yes")
kfold_roc_lr <- prediction(as.numeric(kfold_lr$pred$pred), attrition$Attrition)
plot(performance(kfold_roc_lr, measure = "tpr", x.measure = "fpr"), colorize = TRUE)

#svm
kfold_svm <- train(Attrition~., attrition, trControl = train_control_kfold, method = "svmLinear2")
confusionMatrix(kfold_svm$pred$pred, kfold_svm$pred$obs, positive = "Yes")
kfold_roc_svm <- prediction(as.numeric(kfold_svm$pred$pred), attrition$Attrition)
plot(performance(kfold_roc_svm, measure = "tpr", x.measure = "fpr"), colorize = TRUE)

#SVM
kfold_svm_lin <- train(Attrition~., attrition, trControl = train_control_kfold, method = "svmLinear2",tuneGrid = expand.grid(cost = c(0.01, 0.1, 1, 5, 10)))
confusionMatrix(kfold_svm_lin$pred$pred, kfold_svm_lin$pred$obs, positive = "Yes")
kfold_roc_svmlin <- prediction(as.numeric(kfold_svm_lin$pred$pred), attrition$Attrition)
plot(performance(kfold_roc_svmlin, measure = "tpr", x.measure = "fpr"), colorize = TRUE)

#QDA
kfold_qda <- train(Attrition~., attrition, trControl = train_control_kfold, method = "qda")
confusionMatrix(kfold_qda$pred$pred, kfold_qda$pred$obs, positive = "Yes")



#### TEST SET
attritionTest <-read.csv("attrition_test.csv", header=T)


attritionTest$Education[attritionTest$Education == 1] = "Below College"
attritionTest$Education[attritionTest$Education == 4] = "Master"
attritionTest$Education[attritionTest$Education == 5] = "Doctor"

attritionTest$EnvironmentSatisfaction[attritionTest$EnvironmentSatisfaction == 1] = "Low"
attritionTest$EnvironmentSatisfaction[attritionTest$EnvironmentSatisfaction == 2] = "Medium"
attritionTest$EnvironmentSatisfaction[attritionTest$EnvironmentSatisfaction == 3] = "High"

attritionTest$JobInvolvement[attritionTest$JobInvolvement == 2] = "Medium"
attritionTest$JobInvolvement[attritionTest$JobInvolvement == 4] = "Very High"

attritionTest$JobLevel[attritionTest$JobLevel == 1] = "One"
attritionTest$JobLevel[attritionTest$JobLevel == 2] = "Two"
attritionTest$JobLevel[attritionTest$JobLevel == 3] = "Three"
attritionTest$JobLevel[attritionTest$JobLevel == 4] = "Four"
attritionTest$JobLevel[attritionTest$JobLevel == 5] = "Five"

attritionTest$JobSatisfaction[attritionTest$JobSatisfaction == 1] = "Low"
attritionTest$JobSatisfaction[attritionTest$JobSatisfaction == 3] = "High"
attritionTest$JobSatisfaction[attritionTest$JobSatisfaction == 4] = "Very High"

attritionTest$PerformanceRating[attritionTest$PerformanceRating == 1] = "Low"
attritionTest$PerformanceRating[attritionTest$PerformanceRating == 2] = "Good"
attritionTest$PerformanceRating[attritionTest$PerformanceRating == 3] = "Excellent"
attritionTest$PerformanceRating[attritionTest$PerformanceRating == 4] = "Outstanding"

attritionTest$RelationshipSatisfaction[attritionTest$RelationshipSatisfaction == 1] = "Low"
attritionTest$RelationshipSatisfaction[attritionTest$RelationshipSatisfaction == 2] = "Medium"
attritionTest$RelationshipSatisfaction[attritionTest$RelationshipSatisfaction == 3] = "High"
attritionTest$RelationshipSatisfaction[attritionTest$RelationshipSatisfaction == 4] = "VeryHigh"
attritionTest$StockOptionLevel[attritionTest$StockOptionLevel == 'Zero'] = "0"

attritionTest$StockOptionLevel<-as.numeric(attritionTest$StockOptionLevel)
attritionTest$TrainingTimesLastYear<-as.numeric(attritionTest$TrainingTimesLastYear)
attritionTest$PercentSalaryHike<-as.numeric(attritionTest$PercentSalaryHike)



#nedostajuce vrijednosti

#popunavanje numerickih atributa sa mean 
perSalaryMean<-mean(attritionTest$PercentSalaryHike, na.rm = TRUE)
attritionTest$PercentSalaryHike[is.na(attritionTest$PercentSalaryHike )] <- perSalaryMean
trainLastYear<-mean(attritionTest$TrainingTimesLastYear, na.rm = TRUE)
attritionTest$TrainingTimesLastYear[is.na(attritionTest$TrainingTimesLastYear )] <- trainLastYear

#popunjavanje kategorickih varijabli koristenjem predikcije
test<-attritionTest
kategoricke<- test [, -c(1,4,6,9,10,13,19,20,21,22,24,27,28,29,30,32,33,34,35)]

y <- rpart(kategoricke$JobRole~ kategoricke$Attrition + kategoricke$Department + 
             kategoricke$EducationField,data=kategoricke[!is.na(kategoricke$JobRole ),],
           method="class",na.action = na.omit)
pred<-predict(y,kategoricke[is.na(kategoricke$JobRole ),])
attritionTest$JobRole<- as.factor(attritionTest$JobRole)
#popunjavanje
for (i in 1:nrow(attritionTest)){
  if(is.na(attritionTest$JobRole[i])){
    red<-pred[i,]
    index<-which.max(red)
    attritionTest$JobRole[i]<-levels(attritionTest$JobRole)[index]
  }
}

#department
y <- rpart(kategoricke$Department ~ kategoricke$Attrition + kategoricke$EducationField + 
             kategoricke$JobRole + kategoricke$WorkLifeBalance, 
           data=kategoricke[!is.na(kategoricke$Department),], method="class",na.action = na.omit)
pred<-predict(y,kategoricke[is.na(kategoricke$Department),])

attritionTest$Department<- as.factor(attritionTest$Department)
#popunjavanje department
for (i in 1:nrow(attritionTest)){
  if(is.na(attritionTest$Department[i])){
    red<-pred[i,]
    index<-which.max(red)
    attritionTest$Department[i]<-levels(attritionTest$Department)[index]
  }
}


#education field

y <- rpart(kategoricke$EducationField ~ kategoricke$Attrition + 
             kategoricke$Department + kategoricke$Education + kategoricke$JobRole, 
           data=kategoricke[!is.na(kategoricke$EducationField ),],method="class",na.action = na.omit)
pred<-predict(y,kategoricke[is.na(kategoricke$EducationField ),])

attritionTest$EducationField<- as.factor(attritionTest$EducationField)
#popunjavanje Education Field
for (i in 1:nrow(attritionTest)){
  if(is.na(attritionTest$EducationField[i])){
    red<-pred[i,]
    index<-which.max(red)
    attritionTest$EducationField[i]<-levels(attritionTest$EducationField)[index]
  }
}

#izbacivanje StandardHours i Over18 zato sto su kontante i ne doprinose predikciji

attritionTest <- subset(attritionTest, select = -c(StandardHours,Over18))


# OUTLIERSI 
attritionTest$YearsSinceLastPromotion <- log(attritionTest$YearsSinceLastPromotion- (min(attritionTest$YearsSinceLastPromotion)-1))
attritionTest$HourlyRate <- log(attritionTest$HourlyRate - (min(attritionTest$HourlyRate)-1))
attritionTest$MonthlyIncome <- log(attritionTest$MonthlyIncome- (min(attritionTest$MonthlyIncome)-1))
attritionTest$StockOptionLevel <- log(attritionTest$StockOptionLevel - (min(attritionTest$StockOptionLevel)-1))
attritionTest$TotalWorkingYears <- log(attritionTest$TotalWorkingYears - (min(attritionTest$TotalWorkingYears)-1))
attritionTest$TrainingTimesLastYear <- log(attritionTest$TrainingTimesLastYear - (min(attritionTest$TrainingTimesLastYear)-1))
attritionTest$YearsAtCompany <- log(attritionTest$YearsAtCompany  - (min(attritionTest$YearsAtCompany )-1))
attritionTest$YearsInCurrentRole <- log(attritionTest$YearsInCurrentRole- (min(attritionTest$YearsInCurrentRole)-1))
attritionTest$YearsWithCurrManager <- log(attritionTest$YearsWithCurrManager- (min(attritionTest$YearsWithCurrManager)-1))
attritionTest$NumCompaniesWorked <- log(attritionTest$NumCompaniesWorked- (min(attritionTest$NumCompaniesWorked)-1))

# dodatno ciscenje
Age <- floor(age_calc(as.Date(attritionTest$BirthDate), units="years"))
attritionTest <- data.frame(attritionTest, Age)
#izbacivanje nepotrebnih kolona X, EmployeeCount, EmployeeNumber i BirthDate
attritionTest<- attritionTest [, -c(1,9,10)]
attritionTest<- attritionTest [, -c(31)]


## Evaluacija nad test

#Holdout
#LDA
test_lda <- predict(model_lda, attritionTest)
confusionMatrix(test_lda$class, as.factor(attritionTest$Attrition), positive = "Yes")

#k-nn
pred_knn2 <- knngow_fun(train_z, attritionTest, 10)
pred_knn2 <- as.factor(pred_knn2)
confusionMatrix(pred_knn2, as.factor(attritionTest$Attrition), positive="Yes")

#Logisticka regresija
test_lr <- predict(model_lr, attritionTest, type = "response")

temp1 <- as.numeric(test_lr > 0.5)
temp2 <- mapvalues(temp1, from = c(0, 1), to = c("No","Yes"))
temp3 <- as.factor(temp2)
confusionMatrix(temp3, as.factor(attritionTest$Attrition), positive = "Yes")

#SVM
test_svm <- predict(svmfit, attritionTest)
confusionMatrix(test_svm, as.factor(attritionTest$Attrition), positive = "Yes")


#k-fold
#knn
attrition_knn <- predict(kfold_knn, attritionTest)
confusionMatrix(attrition_knn, as.factor(attritionTest$Attrition), positive = "Yes")

#lda
attrition_lda <- predict(kfold_lda, attritionTest)
confusionMatrix(attrition_lda, as.factor(attritionTest$Attrition), positive = "Yes")

#logisticka regresija
attrition_lr <- predict(kfold_lr, attritionTest)
confusionMatrix(attrition_lr, as.factor(attritionTest$Attrition), positive = "Yes")

#SVM
attrition_svm <- predict(kfold_svm_lin, attritionTest)
confusionMatrix(attrition_svm, as.factor(attritionTest$Attrition), positive = "Yes") 



