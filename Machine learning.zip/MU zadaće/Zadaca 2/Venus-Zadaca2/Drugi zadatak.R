library(MASS)
library(ISLR)
library(lmtest)
library(lattice)
library(car)
library(tree)

#Spajanje
spojeni<-rbind(attrition,attritionTest)

#provjera nedostajucih
count_NA <- sapply(spojeni, function(x) sum(length(which(is.na(x)))))
count_NA <- data.frame(?ount_NA)
count_NA



#balansiranost
prop.table(table(spojeni$Attrition)) 
table(spojeni$Attrition)

#Postavljanje hipoteze

lm.fit =lm(spojeni$MonthlyIncome~.,data=spojeni )
summary(lm.fit)


#ucestalost pojavljivanja greske
sigma(lm.fit)/mean(spojeni$Mont?lyIncome)

plot(predict(lm.fit),residuals(lm.fit))
lines(smooth.spline(predict(lm.fit),residuals(lm.fit)),col="red")

#Izbacivanje nepotrebnih kolona
lm.fit =lm(spojeni$MonthlyIncome~Attrition+JobInvolvement+JobLevel+JobRole+StockOptionLevel,data=spojeni)
?#KORAK1->Ispitivanje pretpostavke linearnosti
plot(predict(lm.fit),residuals(lm.fit))
lines(smooth.spline(predict(lm.fit),residuals(lm.fit)),col="red")

summary(lm.fit)

#KORAK2->Analiza auto-korelacije rezidualnih vrijednosti
library(lmtest)
plot(density(?m.fit$residuals), main="Residuals", xlab="Value")
plot(lm.fit, which=2)



#DW test
dwtest(spojeni$MonthlyIncome~Attrition+JobInvolvement+JobLevel+JobRole+StockOptionLevel,data=spojeni)
#dwtest(spojeni$MonthlyIncome~.,data=spojeni)

#Shapiro.test
shapiro.t?st(lm.fit$residuals)

#KORAK 3->Analiza ''konstantnosti'' varianse rezidualnih vrijednosti
plot(spojeni$MonthlyIncome, lm.fit$residuals)
plot(log(spojeni$MonthlyIncome), lm.fit$residuals)

View(spojeni1)

#KORAK 4->Detekcija nepodobnih izlaznih vrijednosti?(eng. outliers)

#detekcija i uklananje outliera
#length(unique(which(abs(rstudent(lm.fit))>3)))
#spojeni1<-spojeni[-unique(which(rstudent(lm.fit)>3)),]
str(unique(which(abs(rstudent(lm.fit))>3)))
spojeni <- spojeni[-c(225, 283, 437, 543, 595, 615, 617, 66?, 778, 832),] # za model sa 

summary(lm.fit)


#KORAK 5 -> Nepodobne vrijednosti ulaznih varijabli
#Detekcija i uklanjanje leverage points
length(unique(which(hatvalues(lm.fit)>10*(1+1)/nrow(spojeni))))
spojeni1<-spojeni[-unique(which(hatvalues(lm.fit)>10?(1+1)/nrow(spojeni))),]
spojeni1

#KORAK 6 -> Analiza ko-linearnosti ulaznih varijabli

install.packages("car")
library(car)
vif(lm.fit) # Varijable koje imaju VIF veci od 5 je potrebno izbaciti
lm.fit =lm(spojeni$MonthlyIncome ~ spojeni$Attrition + spojen?$JobInvolvement + spojeni$JobRole+ spojeni$StockOptionLevel,data=spojeni) #Kreiranje novog modela
vif(lm.fit)

#SELEKCIJA
#Forward
#ako je * na nekoj koloni to znaci da je ta kolona ukljucena u model
install.packages("leaps")
library(leaps)
regfit.full=reg?ubsets(spojeni$MonthlyIncome~Attrition+JobInvolvement+JobLevel+JobRole+StockOptionLevel+DailyRate+DistanceFromHome+MonthlyRate,spojeni, method="forward")
summary (regfit.full)

#Selekcija backward
regfit.full=regsubsets (spojeni$MonthlyIncome~Attrition+Job?nvolvement+JobLevel+JobRole+StockOptionLevel+DailyRate+DistanceFromHome+MonthlyRate,spojeni, method="backward")
summary (regfit.full)


#Nakon selekcije 
lm.fit =lm(spojeni$MonthlyIncome~spojeni$Attrition+spojeni$JobRole,data=spojeni)
sigma(lm.fit)/mean(sp?jeni$MonthlyIncome)

#KORAK1->Ispitivanje pretpostavke linearnosti

plot(predict(lm.fit),residuals(lm.fit))
lines(smooth.spline(predict(lm.fit),residuals(lm.fit)),col="red")


