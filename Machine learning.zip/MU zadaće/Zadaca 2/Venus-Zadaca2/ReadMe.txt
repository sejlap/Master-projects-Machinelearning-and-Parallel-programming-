Primijetili smo da prilikom spašavanja R file-a, R studio ubacuje ? na random mjesta.
Iz tog razloga, pored R fajlova, priloženi su i txt fajlovi sa identičnim kodom.